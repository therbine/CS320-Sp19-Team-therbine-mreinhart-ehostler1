package edu.ycp.cs320.classes;

public class Room {

}
